# "Haunted office"

A love2d Horror Block Game
"Can you escape!"

## Description

This is a project for my cs50x class and my first game in lua or love2d. it was a fantastic learning experiance. the game is just a single level where you will be chased by a ghostly blue block. the idea is to collect the 4 keys before the ghost touches you ^_^

## Getting Started

Depending on how you decide to play there are 2 set up paths
PATH 1 RAW
    *playing the game directly with love2d installed
PATH 2 .EXE
    *this is the intended way to play and is currently the best experiance also the least amount of work

### Dependencies

* ex. Windows 10

### Installing

read both install paths so you pick the one right for you. RAW lets you see the files to confirm that theres nothing malicious but .EXE is already compiled and faster to start playing.

#### RAW

* if your taking the RAW path then download the files from github
* install love2d
* drag and drop the entire game file on the love.exe
* if you have any problems watch our video tutorial

#### .EXE

* this is a much easier path but it requires some trust
* simply download the compiled .zip from our site
* unzip the file
* in there is the ghostchase.exe just click it twice

## Help

Video demo and tutorial:

## Authors

Contributors names and contact info

1. Shawn D Neuman
EDX
GIT
YOUTUBE

